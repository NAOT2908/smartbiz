# -*- coding: utf-8 -*-

{
    'name': "Tan Co Customizations",
    'summary': "Tan Co Customizations",
    'description': "Tan Co Customizations",
    'author': "SmartBiz",
    'website': "https://www.sbiz.vn",

    # Categories can be used to filter modules in modules listing
    'category': 'SmartBiz Apps',
    'license': 'Other proprietary',
    'version': '1.0',

    # Any module necessary for this one to work correctly
    'depends': [
        'base','sale','purchase','stock','sale_management','purchase_requisition','stock_picking_batch','sale_stock','stock_barcode',
        'mail',
    ],

    # always loaded
    'data': [
        'security/securities.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
        'report/report.xml',
        'report/report_templates.xml',
        'data/data.xml',
    ],

    'assets': {
        'web.assets_backend': [
              'smartbiz_tcc/static/src/**/*.js',
              'smartbiz_tcc/static/src/**/*.scss',
              'smartbiz_tcc/static/src/**/*.xml',
         ],
        'web.assets_qweb': [
         ],
     },

    'qweb': [
    ],

    # only loaded in demonstration mode
    'demo': [
    ],

    # Application settings
    'installable': True,
    'application': True,
}
